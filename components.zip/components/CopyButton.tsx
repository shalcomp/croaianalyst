import React, { useState } from 'react';
import { ClipboardIcon, CheckIcon } from './Icon';

interface CopyButtonProps {
  textToCopy: string;
}

export const CopyButton: React.FC<CopyButtonProps> = ({ textToCopy }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    navigator.clipboard.writeText(textToCopy).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <button 
        onClick={handleCopy}
        className="p-1.5 rounded-md transition-colors duration-200 flex-shrink-0 text-slate-400 hover:bg-slate-700 hover:text-white disabled:cursor-not-allowed"
        aria-label="Copy to clipboard"
        disabled={copied}
    >
        {copied ? 
            <CheckIcon className="h-5 w-5 text-green-400" /> 
            : <ClipboardIcon className="h-5 w-5" />
        }
    </button>
  );
};
