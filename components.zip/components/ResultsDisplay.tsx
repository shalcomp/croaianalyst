
import React from 'react';
import type { AnalysisResult, ConversionElement } from '../types';
import { ScoreCircle } from './ScoreCircle';
import { LightBulbIcon, ClipboardDocumentListIcon, CheckCircleIcon, XCircleIcon, MinusCircleIcon } from './Icon';

interface ResultsDisplayProps {
  result: AnalysisResult;
}

const getRatingStyles = (rating: ConversionElement['rating']): {icon: React.ReactNode, textColor: string, ringColor: string, bgColor: string} => {
  switch (rating) {
    case 'Excellent':
      return { icon: <CheckCircleIcon className="h-5 w-5" />, textColor: 'text-green-300', ringColor: 'ring-green-500/50', bgColor: 'bg-green-500/10' };
    case 'Good':
      return { icon: <CheckCircleIcon className="h-5 w-5" />, textColor: 'text-lime-300', ringColor: 'ring-lime-500/50', bgColor: 'bg-lime-500/10' };
    case 'Needs Improvement':
      return { icon: <MinusCircleIcon className="h-5 w-5" />, textColor: 'text-yellow-300', ringColor: 'ring-yellow-500/50', bgColor: 'bg-yellow-500/10' };
    case 'Poor':
      return { icon: <XCircleIcon className="h-5 w-5" />, textColor: 'text-red-300', ringColor: 'ring-red-500/50', bgColor: 'bg-red-500/10' };
    default:
      return { icon: null, textColor: 'text-slate-300', ringColor: 'ring-slate-500/50', bgColor: 'bg-slate-500/10'};
  }
};


const ConversionElementCard: React.FC<{ title: string, data: ConversionElement }> = ({ title, data }) => {
    const { icon, textColor, ringColor, bgColor } = getRatingStyles(data.rating);
    return (
        <div className={`p-4 rounded-lg ring-1 ${ringColor} ${bgColor}`}>
            <div className="flex items-center justify-between">
                <h4 className="font-semibold text-white">{title}</h4>
                <div className={`flex items-center gap-2 text-sm font-medium ${textColor}`}>
                    {icon}
                    <span>{data.rating}</span>
                </div>
            </div>
            <p className="text-slate-400 text-sm mt-2">{data.comment}</p>
        </div>
    );
}


export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result }) => {
  return (
    <div className="bg-slate-800/30 backdrop-blur-lg border border-slate-700 rounded-xl shadow-2xl shadow-black/20 animate-fade-in-up">
        <div className="p-6 border-b border-slate-700">
            <h2 className="text-2xl font-bold text-white text-center">Analysis Report</h2>
        </div>
        <div className="p-6 border-b border-slate-700 flex flex-col md:flex-row items-center gap-6 bg-slate-900/20">
            <div className="flex-shrink-0">
                <ScoreCircle score={result.optimizationScore} />
            </div>
            <div className="text-center md:text-left">
                <h3 className="text-lg font-semibold text-white">Overall Summary</h3>
                <p className="text-slate-300 mt-1 max-w-prose">{result.summary}</p>
            </div>
        </div>

      <div className="p-6 border-b border-slate-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <ClipboardDocumentListIcon className="h-6 w-6 text-cyan-400" />
            Core Conversion Elements
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ConversionElementCard title="Call to Action (CTA)" data={result.conversionElements.cta} />
            <ConversionElementCard title="Value Proposition" data={result.conversionElements.valueProposition} />
            <ConversionElementCard title="Content Clarity" data={result.conversionElements.contentClarity} />
            <ConversionElementCard title="Trust Signals" data={result.conversionElements.trustSignals} />
            <ConversionElementCard title="Mobile Friendliness" data={result.conversionElements.mobileFriendliness} />
            {result.adMatchAnalysis && (
                 <div className="p-4 rounded-lg ring-1 ring-cyan-500/50 bg-cyan-500/10 md:col-span-2">
                    <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-white">Ad & Page Alignment</h4>
                        <span className="text-sm font-bold text-white bg-cyan-500/20 text-cyan-300 px-2.5 py-1 rounded-full">{result.adMatchAnalysis.score}/100</span>
                    </div>
                    <p className="text-slate-400 text-sm mt-2">{result.adMatchAnalysis.feedback}</p>
                </div>
            )}
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <LightBulbIcon className="h-6 w-6 text-yellow-300" />
            AI Recommendations
        </h3>
        <ul className="space-y-3">
          {result.recommendations.map((rec, index) => (
            <li key={index} className="flex items-start gap-3 stagger-in" style={{ animationDelay: `${index * 100}ms`}}>
                <span className="text-cyan-400 pt-1">&#x27A4;</span>
                <span className="text-slate-300">{rec}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
