import React from 'react';
import { CheckCircleIcon, ChartBarIcon } from './Icon';

const Feature: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <li className="flex items-center gap-3">
        <CheckCircleIcon className="h-5 w-5 text-cyan-400 flex-shrink-0" />
        <span className="text-slate-400">{children}</span>
    </li>
);

export const WelcomeState: React.FC = () => {
    return (
        <div className="bg-slate-800/30 backdrop-blur-lg border border-slate-700 rounded-xl p-8 text-center animate-fade-in-up shadow-2xl shadow-black/20">
            <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/20">
                <ChartBarIcon className="h-8 w-8 text-white" />
            </div>
            <h2 className="mt-6 text-xl font-bold text-white">Ready for Analysis</h2>
            <p className="mt-2 text-slate-400 max-w-md mx-auto">
                Select an analysis type and enter a website URL to begin. The AI will provide a complete conversion optimization report.
            </p>
            <div className="mt-8 text-left max-w-sm mx-auto">
                <h3 className="font-semibold text-white text-center mb-4">You will get:</h3>
                <ul className="space-y-2">
                    <Feature>An overall optimization score (0-100)</Feature>
                    <Feature>Analysis of core conversion elements</Feature>
                    <Feature>PPC Ad & Landing Page alignment rating</Feature>
                    <Feature>Actionable AI-powered recommendations</Feature>
                </ul>
            </div>
        </div>
    );
};
