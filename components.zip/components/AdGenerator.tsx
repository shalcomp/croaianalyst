
import React from 'react';
import type { GeneratedAds } from '../types';
import { Loader } from './Loader';
import { PencilSquareIcon } from './Icon';
import { CopyButton } from './CopyButton';

interface AdGeneratorProps {
  onGenerate: () => void;
  generatedAds: GeneratedAds | null;
  isLoading: boolean;
}

const AdList: React.FC<{title: string, items: string[]}> = ({ title, items }) => (
    <div>
        <h3 className="text-base font-semibold text-white">{title}</h3>
        <ul className="mt-2 space-y-2">
            {items.map((item, i) => (
                <li key={i} className="bg-slate-900/70 p-3 rounded-lg flex items-center justify-between gap-4 text-sm">
                    <span className="text-slate-300">{item}</span>
                    <CopyButton textToCopy={item} />
                </li>
            ))}
        </ul>
    </div>
);

export const AdGenerator: React.FC<AdGeneratorProps> = ({ onGenerate, generatedAds, isLoading }) => {
  return (
    <div className="bg-slate-800/30 backdrop-blur-lg border border-slate-700 rounded-xl p-6 shadow-2xl shadow-black/20">
      <h2 className="text-lg font-bold text-white">Generate Ad Copy</h2>
      <p className="text-sm text-slate-400 mt-1">
        Use AI to create conversion-optimized ad copy based on the landing page content.
      </p>

      <button
        onClick={onGenerate}
        disabled={isLoading}
        className="mt-4 w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-cyan-500/50 text-sm font-semibold rounded-lg shadow-sm text-cyan-200 bg-cyan-500/10 hover:bg-cyan-500/20 disabled:bg-slate-600/50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500 transition-all"
      >
        <PencilSquareIcon className="h-5 w-5" />
        {isLoading ? 'Generating...' : 'Generate Optimized Ads'}
      </button>

      {isLoading && <div className="mt-4"><Loader text="Writing ad copy..." /></div>}
      
      {generatedAds && (
        <div className="mt-6 space-y-6 animate-fade-in-up">
            <AdList title="Generated Headlines" items={generatedAds.headlines} />
            <AdList title="Generated Descriptions" items={generatedAds.descriptions} />
        </div>
      )}
    </div>
  );
};
